<div class="footer-wrapper">
      <div class="footer-section f-section-1">
        <p class=""><a>Developed By TechNomads  <i class="mb-1 text-primary ml-1 icon-small" data-feather="heart"></i> </a></p>
      </div>
      <div class="footer-section f-section-2">
        <p class="">{{ @Session::get('fullname') }}</p>
      </div>
    </div>