<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<title>Admin - Bigdaddy</title>
<link rel="icon" type="image/x-icon" href="{{ asset('images/favicon.png')}}"/>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
<link href="{{ asset('admin_assets/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('admin_assets/assets/css/plugins.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('admin_assets/assets/css/authentication/form-2.css') }}" rel="stylesheet" type="text/css" />
 <!--link href="{{ asset('admin_assets/plugins/loaders/custom-loader.css')}}" rel="stylesheet" type="text/css" /-->
  <link rel="stylesheet" href="{{ asset('admin_assets/plugins/font-icons/fontawesome/css/all.min.css')}}">
    <link rel="stylesheet" href="{{ asset('admin_assets/plugins/font-icons/fontawesome/css/regular.css')}}">
    <link rel="stylesheet" href="{{ asset('admin_assets/plugins/font-icons/fontawesome/css/fontawesome.css')}}">
    <link href="{{ asset('admin_assets/plugins/sweetalerts/sweetalert2.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('admin_assets/plugins/sweetalerts/sweetalert.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('admin_assets/assets/css/components/custom-sweetalert.css')}}" rel="stylesheet" type="text/css" />
   <link href="{{ asset('admin_assets/assets/css/loader.css')}}" rel="stylesheet" type="text/css" />
    <script src="{{ asset('admin_assets/assets/js/loader.js')}}"></script>
<link rel="stylesheet" href="{{ asset('admin_assets/assets/css/style.css')}}">

 <link href="{{ asset('admin_assets/assets/css/elements/tooltip.css')}}" rel="stylesheet" type="text/css" />

<!-- END GLOBAL MANDATORY STYLES -->
